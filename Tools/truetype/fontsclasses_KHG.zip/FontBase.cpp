#include "FontBase.h"

IFont::IFont()
{
	m_eFontType = EFontType_Unknown;

	m_texture = 0;
	m_maxWidth = m_maxHeight = 0;
	m_textureSizeWasModified = false;

	m_iFontSize = -1; // any size
	m_fFontScale = 1.0f;
}

void IFont::GetFontMetrics(int& maxCharWidth, int& maxCharHeight) const
{
	maxCharWidth = m_maxWidth;
	maxCharHeight = m_maxHeight;
}

void IFont::GetFontMetrics(const char* text, int textLen, int& textWidth, int& textHeight)
{
	GetFontMetrics(text, textLen, -1, textWidth, textHeight);
}

int IFont::GetTextWidth(const char* text, int textLen)
{
	int textWidth, textHeight;
	GetFontMetrics(text, textLen, -1, textWidth, textHeight);
	return textWidth;
}

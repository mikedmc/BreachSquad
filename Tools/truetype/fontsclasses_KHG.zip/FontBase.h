#pragma once

#include "Kernel/CommonDefs.h"
#include "Kernel/HashedString.h"

struct sFontChar
{
	public:
		sFontChar()
		{
			advance_x = offset_x = 0;

			x = y = 0;
			width = height = 0;

			glyphIdx = 0; // 0 = no glyph index
		}

	public:
		int advance_x; // for bitmap fonts, will be equal to width
		int offset_x; // for bitmap fonts, will be 0

		int x, y; // lower left corner of this character in texture pixel coordinates [0..texWidth/texHeight]
		int width, height;

		unsigned int glyphIdx; // only used for HybridFonts
};

enum EFontType
{
	EFontType_Unknown = 0x00,

	EFontType_Bitmap,
	EFontType_Hybrid
};

class IFont
{
	public:
		IFont();
		virtual ~IFont() {};

	public:
		EFontType		m_eFontType;
		HashedString	m_sFontName;
		HashedString	m_sFontFile;
		int				m_iFontSize;
		float			m_fFontScale; // added this to try scaling font size when resolution changes, doesn't work great

		unsigned int	m_texture; // a TextureManager::TextureId
		int				m_maxWidth; // for quick size calculations
		int				m_maxHeight;

		bool			m_textureSizeWasModified; // flag the renderer that the texture size was modified, so that we can recompute text coords

	public:
		virtual bool Load() = 0;
		virtual const sFontChar* GetChar(const unsigned int key) = 0;
		virtual void GetFontMetrics(const char* text, int textLen, int kerning, int& textWidth, int& textHeight) = 0;
		virtual bool GetHasKerning() const { return false; }
		virtual int GetKerning(const sFontChar* /*prevChar*/, const sFontChar* /*currChar*/) const { return 0; }

		void GetFontMetrics(int& maxCharWidth, int& maxCharHeight) const;
		void GetFontMetrics(const char* text, int textLen, int& textWidth, int& textHeight);
		int GetTextWidth(const char* text, int textLen);
};

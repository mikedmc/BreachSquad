#include "FontBitmap.h"
#include "TextureManager.h"
#include "Kernel/Log.h"
#include "Kernel/Utils.h"
#include "Kernel/FileManager.h"
#include "tinyxml2/tinyxml2.h"

CFontBitmap::CFontBitmap()
	: IFont()
{
	m_eFontType = EFontType_Bitmap;
}

CFontBitmap::~CFontBitmap()
{
	g_textureManager->Delete(m_texture);
}

bool CFontBitmap::Load( void )
{
	tinyxml2::XMLDocument fontXml;
	char szName[ MAX_PATH_STD ];

	// load texture
	sprintf( szName, "%s.tga", m_sFontFile.GetString() );

	m_texture = g_textureManager->Load( szName );
	//const Texture* pTexture = g_textureManager->Get(m_texture);

	// load xml
	sprintf( szName, "%s.xml", m_sFontFile.GetString() );

	// load map first
	bool bResult = g_fileManager->LoadXML( szName, fontXml );
	if( !bResult )
	{
		g_pLog->Write("[Error] CFontBitmap::Load() Could not load xml '%s' for font %s! \n", szName, m_sFontFile.GetString() );
		return false;
	}
	
	tinyxml2::XMLElement* pRoot = fontXml.FirstChildElement( "fontMetrics" )->ToElement();
	if( !pRoot )
	{
		g_pLog->Write("[Error] CFontBitmap::Load() Could not find 'fontMetrics' tag for font '%s' in xml file '%s'! \n", m_sFontFile.GetString(), szName );
		return false;
	}

	for( pRoot = pRoot->FirstChildElement( "character" ); pRoot; pRoot = pRoot->NextSiblingElement( "character" ) )
	{
		int characterKey = 0;
		pRoot->QueryIntAttribute( "key", &characterKey );
		if (characterKey >= COUNT_OF(chars))
		{
			g_pLog->Write("[Error] CFontBitmap::Load() Key %d is larger than our system supports!\n", characterKey);
			DEBUG_BREAK();
			continue;
		}

		sFontChar& fontChar = chars[ characterKey ];
		pRoot->FirstChildElement("x")->QueryIntText(&fontChar.x);
		pRoot->FirstChildElement("y")->QueryIntText(&fontChar.y);
		pRoot->FirstChildElement("width")->QueryIntText(&fontChar.width);
		pRoot->FirstChildElement("height")->QueryIntText(&fontChar.height);

		fontChar.advance_x = fontChar.width;

		if( m_maxWidth < fontChar.width )
			m_maxWidth = fontChar.width;
		if( m_maxHeight < fontChar.height )
			m_maxHeight = fontChar.height;
	}

	return true;
}

void CFontBitmap::GetFontMetrics( const char* text, int textLen, int kerning, int& textWidth, int& textHeight )
{
	if( kerning > 0 )
	{
		textHeight = kerning;
		textWidth = kerning * textLen;
		return;
	}

	textHeight = (int)m_maxHeight;
	textWidth = 0;

	for ( int n = 0; n < textLen; )
	{
		unsigned char seqLen = (unsigned char)-1;
		unsigned int uniCharCodepoint = Utils::UTF8To32( &text[n], seqLen );

		if( seqLen == (unsigned char)-1 )
			break; // malformated UTF8; what to do, what to do .. 

		n += seqLen;

		const sFontChar* character = GetChar( uniCharCodepoint );
		textWidth += (int)character->width;
	}
}

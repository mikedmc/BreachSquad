#pragma once

#include "Kernel/CommonDefs.h"
#include "FontBase.h"

class CFontBitmap : public IFont
{
	public:
		CFontBitmap();
		~CFontBitmap();

	private:
		sFontChar chars[1110]; // hacked max size based on current font bitmaps

	public:
		virtual const sFontChar* GetChar( const unsigned int key )
		{
			return &chars[key % (sizeof(chars) / sizeof(chars[0]))];
		}

		virtual void GetFontMetrics(const char* text, int textLen, int kerning, int& textWidth, int& textHeight);
		virtual bool Load();
};

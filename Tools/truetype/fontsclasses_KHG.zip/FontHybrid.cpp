﻿#include "FontHybrid.h"
#include "TextureManager.h"
#include "Render.h"
#include "Render2D.h"
#include "Kernel/Log.h"
#include "Kernel/Utils.h"
#include "Kernel/FileManager.h"
#include "Kernel/Math.h"
#include "Kernel/OS.h"
#include "tinyxml2/tinyxml2.h"
#include "ft2build.h"
#include FT_FREETYPE_H
#include FT_GLYPH_H

static const int g_textureMaxHeight = 8192;

CFontHybrid::CFontHybrid()
	: IFont()
{
	m_eFontType = EFontType_Hybrid;

	m_face = NULL;

	m_textureWidth = 1024;
	m_textureHeight = 1; // dummy value; will be computed based on actual char height

	m_addChar_xPos = 0;
	m_addChar_yPos = 0;

	m_wantedCharHeight = -1;
	m_actualCharHeight = -1;

	m_paddingLeft = 4; // auto-padded if unspecified here or in the xml
	m_paddingRight = 0;

	m_paddingTop = 4; // auto-padded if unspecified here or in the xml
	m_paddingBottom = 0;

	m_bHasCustomKerning = false;
}

CFontHybrid::~CFontHybrid()
{
	//unsigned char* pixels = (unsigned char*)g_textureManager->GetPixels((TextureId)m_texture);
	//char fontFileName[256];
	//sprintf( fontFileName, "%s/%s.png", OS_GetWritableGameFolder(), m_sFontName.GetString() );
	//TextureHelpers::SavePNG( fontFileName, pixels, g_textureManager->Get(m_texture)->width, g_textureManager->Get(m_texture)->height, 8 );

	g_textureManager->Delete(m_texture);
}

void CFontHybrid::GrowTexture( void )
{
	const int spaceNeededForChar = m_paddingTop + m_actualCharHeight + m_paddingBottom;
	const int numCharsPerCurrentTexHeight = m_textureHeight / spaceNeededForChar;
	const int newTextureHeight = Math::NextPowerOfTwo( ( numCharsPerCurrentTexHeight +1 ) * spaceNeededForChar );

	if( newTextureHeight > g_textureMaxHeight)
	{
		// next time start with a larger width...
		DEBUG_BREAK();
		return;
	}

	m_textureSizeWasModified = true;

	const Texture* pTexture = g_textureManager->Get(m_texture);

	//
	// create a temporary texture into which we copy the old contents. Then we resize the font texture, copy the old contents back into it, then add the new character.

	unsigned int tempFramebuffer = Render::CreateFrameBuffer();
	Render::PushFrameBuffer(tempFramebuffer);
	Render::AttachToFrameBuffer(Render::FB_ATTACHMENT_COLOR0, pTexture->id, true, TextureHelpers::IsSRGB(pTexture->type), pTexture->width, pTexture->height);
		TextureId tempTexture = g_textureManager->Create("font_temp_grow", pTexture->width, pTexture->height, 1, pTexture->type, NULL);
		Render::CopyFramebufferToTexture(g_textureManager->Get(tempTexture)->id, 0, 0, pTexture->width, pTexture->height);
	Render::PopFrameBuffer();

	g_textureManager->Resize(m_texture, m_textureWidth, newTextureHeight, 1);

	Render::PushFrameBuffer(tempFramebuffer);
	Render::AttachToFrameBuffer(Render::FB_ATTACHMENT_COLOR0, pTexture->id, true, TextureHelpers::IsSRGB(pTexture->type), pTexture->width, pTexture->height); // do we need to do this again?
	Render::ClearScene(Render::COLOR_BUFFER_BIT, 0);
	Render::SetBlending(false); // TODO: this should be restored

	// render old texture inside the new texture framebuffer
	Matrix previousProjection = Render2D::GetProjectionMatrix();
	Matrix previousModel, previousView;
	Render2D::GetModelViewMatrix(previousModel, previousView);
	Matrix m;
	Math::BuildOrthographicProjection(0.0f, (float)pTexture->width, 0.0f, (float)pTexture->height, -1.0f, 1.0f, m);
	Render2D::SetProjectionMatrix(m);
	Render2D::SetModelViewMatrix(Matrix_identity, Matrix_identity);

	const Texture* pOldTexture = g_textureManager->Get(tempTexture);
	Render2D::Quad q;
	q.v[0].pos = Vector3_zero;
	q.v[1].pos = Vector3((float)pOldTexture->width, 0.f, 0.f );
	q.v[2].pos = Vector3((float)pOldTexture->width, (float)pOldTexture->height, 0.f);
	q.v[3].pos = Vector3(0, (float)pOldTexture->height, 0);

	// translate to first row
	for( int i(0); i < 4; ++i )
		q.v[i].pos.y += pTexture->height - pOldTexture->height;

	Render2D::DrawQuad(&q, pOldTexture->id);

	Render::PopFrameBuffer();
	Render::DeleteFrameBuffer(tempFramebuffer);

	// save new data ( tex + new height )
	m_textureHeight = newTextureHeight;

	// delete old tex
	g_textureManager->Delete(tempTexture);

	// restore state
	Render2D::SetProjectionMatrix(previousProjection);
	Render2D::SetModelViewMatrix(previousModel, previousView);
}

sFontChar* CFontHybrid::AddChar(const unsigned int key)
{
	sFontChar* pFontChar = &m_charMap[key]; // add and get ptr to it

	// key == 9 || key == 10 || key == 11 || key == 13) // tab, line feed, vertical tab, carriage return . 8203 is U+200B which is zero-width-space u8"​" (font doesn't want to render it with zero width...)
	if (key < 32 || key == 8203)
	{
		pFontChar->x = 0;
		pFontChar->y = 0;
		pFontChar->width = 0;
		pFontChar->height = 0;
		return pFontChar;
	}

	if (m_bHasCustomKerning)
		pFontChar->glyphIdx = FT_Get_Char_Index(m_face, key);

	FT_Error error = FT_Set_Pixel_Sizes(m_face, 0, m_iFontSize); // 'iFontSize' px w/h; 72x72 dpi
	if (error != 0)
	{
		LOG("[Error] CFontHybrid::addChar() Could not set font pixel sizes \n");
	}

	error = FT_Load_Char(m_face, key, FT_LOAD_RENDER);// | FT_LOAD_NO_SCALE );
	if (error != 0)
	{
		LOG("[Error] CFontHybrid::addChar() Could not load char '%ud'!\n", key);
	}

	FT_GlyphSlot slot = m_face->glyph;
	pFontChar->advance_x = (slot->metrics.horiAdvance >> 6);
	pFontChar->offset_x = (slot->metrics.horiBearingX >> 6);

	const int charTextureHeight = m_actualCharHeight;
	const int charActualWidth = slot->bitmap.width;
	const int charActualHeight = slot->bitmap.rows;

	if (!charActualWidth || !charActualHeight)
	{
		// if we need to create an actual fake space, uncomment below, don't return here and continue
		ASSERT(key == 32 || key == 160); // 160 is non-breaking space

		return pFontChar;
		
		//ASSERT((slot->advance.x >> 6) == pFontChar->advance_x);
		//charActualWidth = (slot->advance.x >> 6);
		//charActualHeight = charTextureHeight;
	}

	const Texture* pTexture = g_textureManager->Get(m_texture);

	// check for moving to a new line, when going over the width of the current texture
	if ((m_addChar_xPos + m_paddingLeft + charActualWidth + m_paddingRight) > pTexture->width) // if the texture is 'clamp to edge', we must use >= here
	{
		m_addChar_xPos = 0;

		if ((m_addChar_yPos + (m_paddingTop + charTextureHeight + m_paddingBottom) * 2) > pTexture->height) // if the texture is 'clamp to edge', we must use >= here
		{
			// increase height of our font atlas texture
			GrowTexture();

			// get reference to new texture; updated height
			pTexture = g_textureManager->Get(m_texture);
			m_addChar_yPos += m_paddingTop + charTextureHeight + m_paddingBottom;
		}
		else
			m_addChar_yPos += m_paddingTop + charTextureHeight + m_paddingBottom;
	}

	// set char start pos
	pFontChar->x = (m_paddingLeft + m_addChar_xPos);
	pFontChar->y = (m_paddingTop + m_addChar_yPos);

	// set font char width / height
	pFontChar->width = (charActualWidth + m_paddingRight);
	pFontChar->height = (charTextureHeight + m_paddingBottom);

	// advance
	m_addChar_xPos = pFontChar->x + charActualWidth + m_paddingRight;

	// flip char to match opengl coordinate system
	TextureHelpers::VerticalFlip(slot->bitmap.buffer, slot->bitmap.width, slot->bitmap.rows, 1);

	// update part of the opengl texture; upload our char
	const int charOffset = m_maxAboveBaseline_y - slot->bitmap_top;
	g_textureManager->UpdateMipRegion( m_texture, 0, 
										pFontChar->x,
										pTexture->height - (pFontChar->y + charOffset) - charActualHeight,
										charActualWidth, charActualHeight, slot->bitmap.buffer);

	if (m_maxWidth < (pFontChar->width * m_fFontScale))
	{
		DEBUG_BREAK();
		m_maxWidth = (int)(pFontChar->width * m_fFontScale);
	}

	if (m_maxHeight < (pFontChar->height * m_fFontScale))
	{
		DEBUG_BREAK();
		m_maxHeight = (int)(pFontChar->height * m_fFontScale);
	}

	return pFontChar;
}

const sFontChar* CFontHybrid::GetChar( const unsigned int key )
{
	std::unordered_map< unsigned int, sFontChar >::const_iterator findIt = m_charMap.find( key );
	if( findIt == m_charMap.end() )
	{
		// we don't have that specified character, create it !
		return AddChar( key );
	}
	return &findIt->second;
}

bool CFontHybrid::Load( void )
{
	// adds common characters initially to the font to minimize texture writes at runtime
	// TODO: we shouldn't do any caching when using localizations, for now I'll leave it on to check for errors
	LOG_IF_VERBOSE("Caching alphabet for %s\n", m_sFontName.GetString());
	const char alphabet[] =
	{
		// actually used punctuation
		" !?,.':<>\"@#$%&*()-+_\\/"
		//" !?,.':<>\"@#$%^&*()-+_=[]{}|\\/"

		// maybe, for some fonts
		//"0123456789"

		// maybe, for western languages
		//"abcdefghijklmnopqrstuvwxyz"
		//"ABCDEFGHIJKLMONPQRSTUVWXYZ"
	};

	for (int i(0); i < COUNT_OF(alphabet) - 1; ++i)
	{
		AddChar(alphabet[i]);
	}

	return true;
}


// for a givven font face, checks all the charmaps
// and selects the one that supports UCS4 character maps
// so that we then lookup charaters by their UCS4 code
//
int ForceUCS4CharMap( FT_Face ftf )
{
	for(int i = 0; i < ftf->num_charmaps; i++)
	{
        if(  ((ftf->charmaps[i]->platform_id == 3)
             && (ftf->charmaps[i]->encoding_id == 10))
          || ((ftf->charmaps[i]->platform_id == 0)
             && (ftf->charmaps[i]->encoding_id == 10)))
		{
			return FT_Set_Charmap( ftf, ftf->charmaps[i] );
		}
	}
    return -1;
}

bool CFontHybrid::InitTrueTypeFont( FT_Library library, FT_Face fontFace )
{
	FT_Error error;

	m_face = fontFace;
	m_library = library;

	// was trying to match the font size to the initially chosen size, while changing resolution
	//   doesn't look good when downscaling (need to make it pixel perfect), but looks ok when upscaling
	//const float fs = 1440.0f / Render::GetBackbufferHeight();
	//if (fs < 1.0f)
	//{
	//	m_fFontScale = fs;
	//	int fontSize = (int)(m_iFontSize / m_fFontScale + 0.5f);
	//	m_fFontScale = (float)m_iFontSize / fontSize;
	//	m_iFontSize = fontSize;
	//}

	if (m_paddingLeft == 0)
		m_paddingLeft = Max(2, m_iFontSize / 4);
	if (m_paddingTop == 0)
		m_paddingTop = Max(2, m_iFontSize / 4);

	ForceUCS4CharMap( m_face );

	// 'iFontSize' px w/h; 72x72 dpi
	//FT_Size_RequestRec sizereq;
	//memset(&sizereq, 0, sizeof(sizereq));
	//sizereq.type = FT_SIZE_REQUEST_TYPE_NOMINAL;
	//sizereq.width = 0;
	//sizereq.height = m_iFontSize;
	//error = FT_Request_Size(m_face, &sizereq);	
	//FT_Select_Size

	error = FT_Set_Pixel_Sizes( m_face, 0, m_iFontSize );
	if (error != 0)
	{
		g_pLog->Write("[Error] CFontHybrid::LoadTrueTypeFont() Could not set font pixel sizes \n");
		return false;
	}

	m_bHasCustomKerning = FT_HAS_KERNING(m_face);
	ASSERT(!m_bHasCustomKerning); // just want to see a font that has this, haven't tested it in dk2

	// compute pixels above / below font char baseline, char size in texture and
	// texture initial height, power of 2, so that our char size fits
	//

	m_maxAboveBaseline_y = (int)round(m_face->bbox.yMax * m_iFontSize / m_face->units_per_EM + 0.5f);
	m_minBelowBaseline_y = (int)round(m_face->bbox.yMin * m_iFontSize / m_face->units_per_EM - 0.5f);

	// char size: compute and save for later usage
	m_actualCharHeight = m_maxAboveBaseline_y - m_minBelowBaseline_y;
	if( m_wantedCharHeight != -1 )
	{
		m_maxAboveBaseline_y = m_iFontSize;
		m_actualCharHeight = m_wantedCharHeight;
	}

	m_maxHeight = (int)(m_actualCharHeight * m_fFontScale);
	m_maxWidth = (int)(m_maxHeight * 0.8f); // not actually true. Gets added to below, when more chars are parsed

	// texture height based on char size + padding
	const int rowPixelHeight = m_paddingTop + m_actualCharHeight + m_paddingBottom;

	// try to estimate how much space we're gonna need and resize texture accordingly. For some languages we might still need to grow the texture later on
	int numRowsRequired = 3;// Max(2, 90 / (m_textureWidth / m_maxWidth));
	m_textureHeight = Min(512, Math::NextPowerOfTwo(rowPixelHeight * numRowsRequired));
	// create texture
	m_texture = g_textureManager->Create( m_sFontName.GetString(), m_textureWidth, m_textureHeight, 1, Texture::TYPE_R8, NULL );

	// don't clamp, we might end up with hard letter edges if a letter happens to be right at the texture's edge. With wrapping we will use some of the existing padding from the other side.
	//   if we want to clamp, make sure you change > to >= in AddChar, you know where.
	g_textureManager->SetWrapMode(m_texture, Texture::WRAP_REPEAT, Texture::WRAP_REPEAT);
	const Texture* pTexture = g_textureManager->Get(m_texture);

	// clear texture
	unsigned int tempFramebuffer = Render::CreateFrameBuffer();
	Render::PushFrameBuffer(tempFramebuffer);
	Render::AttachToFrameBuffer( Render::FB_ATTACHMENT_COLOR0, pTexture->id, true, TextureHelpers::IsSRGB(pTexture->type), pTexture->width, pTexture->height );
		Render::ClearScene( Render::COLOR_BUFFER_BIT, 0 );
	Render::PopFrameBuffer();
	Render::DeleteFrameBuffer( tempFramebuffer );
	return true;
}


bool CFontHybrid::LoadBitmapFont( void )
{
	tinyxml2::XMLDocument fontXml;
	char szName[ MAX_PATH_STD ];

	// load texture
	sprintf( szName, "%s.tga", m_sFontName.GetString() );
	m_texture = g_textureManager->Load( szName );
	//const Texture* pTexture = g_textureManager->Get( m_texture );

	// load xml
	sprintf( szName, "%s.xml", m_sFontName.GetString() );

	// load map first
	bool bResult = g_fileManager->LoadXML( szName, fontXml );
	if( !bResult )
	{
		g_pLog->Write("[Error] CFontHybrid::LoadBitmapFont() Could not load xml '%s' for font %s! \n", szName, m_sFontName.GetString() );
		return false;
	}
	
	tinyxml2::XMLElement* pRoot = fontXml.FirstChildElement( "fontMetrics" )->ToElement();
	if( !pRoot )
	{
		g_pLog->Write("[Error] CFontHybrid::LoadBitmapFont() Could not find 'fontMetrics' tag for font '%s' in xml file '%s'! \n", m_sFontName.GetString(), szName );
		return false;
	}

	for( pRoot = pRoot->FirstChildElement( "character" ); pRoot; pRoot = pRoot->NextSiblingElement( "character" ) )
	{
		int characterKey = 0;
		pRoot->QueryIntAttribute( "key", &characterKey );
			
		sFontChar& fontChar = m_charMap[ characterKey ]; // auto-magically added and ref returned
		pRoot->FirstChildElement("x")->QueryIntText(&fontChar.x);
		pRoot->FirstChildElement("y")->QueryIntText(&fontChar.y);
		pRoot->FirstChildElement("width")->QueryIntText(&fontChar.width);
		pRoot->FirstChildElement("height")->QueryIntText(&fontChar.height);

		if( m_maxWidth < fontChar.width )
			m_maxWidth = fontChar.width;
		if( m_maxHeight < fontChar.height )
			m_maxHeight = fontChar.height;
	}

	return true;
}

bool CFontHybrid::SaveBitmapFont( const char* pSavePath )
{
	tinyxml2::XMLDocument doc;
	tinyxml2::XMLElement *pRoot = doc.NewElement("fontMetrics");
	
	char tgaFileName[MAX_PATH_STD];
	sprintf( tgaFileName, "%s.tga", m_sFontName.GetString() );

	pRoot->SetAttribute( "file", tgaFileName );
	doc.LinkEndChild(pRoot);

	const Texture* pTexture = g_textureManager->Get( m_texture );

	for( std::unordered_map< unsigned int, sFontChar >::iterator it = m_charMap.begin(); it != m_charMap.end(); ++it )
	{
		tinyxml2::XMLElement* pCharacter = doc.NewElement("character");
		pCharacter->SetAttribute( "key", it->first );

		// add new nodes to character
		tinyxml2::XMLElement* pElementX = doc.NewElement("x");
		pElementX->SetText( static_cast<float>( it->second.x ) * static_cast<float>( pTexture->width ) );
		pCharacter->LinkEndChild( pElementX );

		tinyxml2::XMLElement* pElementY = doc.NewElement("y");
		pElementY->SetText( static_cast<float>( it->second.y ) * static_cast<float>( pTexture->height ) );
		pCharacter->LinkEndChild( pElementY );

		tinyxml2::XMLElement* pElementWidth = doc.NewElement("width");
		pElementWidth->SetText( it->second.width );
		pCharacter->LinkEndChild( pElementWidth );

		tinyxml2::XMLElement* pElementHeight = doc.NewElement("height");
		pElementHeight->SetText( it->second.height );
		pCharacter->LinkEndChild( pElementHeight );

		// add char to root
		pRoot->LinkEndChild(pCharacter);
	}

	// save build xml
	char xmlFullFilePath[MAX_PATH_STD];
	sprintf( xmlFullFilePath, "%s/%s.xml", pSavePath, m_sFontName.GetString() );
	g_fileManager->SaveXML(doc, xmlFullFilePath);

	// also save font texture
	unsigned char* pixels = (unsigned char*)g_textureManager->GetPixels(m_texture);

	char tgaFullFilePath[MAX_PATH_STD];
	sprintf( tgaFullFilePath, "%s/%s", pSavePath, tgaFileName );

	TextureHelpers::SaveTGA( tgaFullFilePath, pixels, pTexture->width, pTexture->height, TextureHelpers::GetBppFromType(pTexture->type) );
	delete[] pixels;

	return true;
}

void CFontHybrid::GetFontMetrics( const char* text, int textLen, int kerning, int& textWidth, int& textHeight )
{
	if (kerning > 0)
	{
		textHeight = kerning;
		textWidth = kerning * textLen;
		return;
	}

	int tw = 0;

	if (m_bHasCustomKerning)
	{
		unsigned int previousGlyphIdx = 0;
		for ( int n = 0; n < textLen; )
		{
			unsigned char seqLen = (unsigned char)-1;
			unsigned int uniCharCodepoint = Utils::UTF8To32(&text[n], seqLen);
			if (seqLen == (unsigned char)-1)
				break; // malformated UTF8; what to do, what to do .. 

			n += seqLen;

			const sFontChar* character = GetChar(uniCharCodepoint);
			tw += character->advance_x;
		
			if (m_bHasCustomKerning && previousGlyphIdx)
			{
				FT_Vector delta;
				FT_Get_Kerning(m_face, previousGlyphIdx, character->glyphIdx, FT_KERNING_DEFAULT, &delta);
				tw += (delta.x >> 6);
			}

			previousGlyphIdx = character->glyphIdx;
		}
	}
	else
	{
		for (int n = 0; n < textLen;)
		{
			unsigned char seqLen = (unsigned char)-1;
			unsigned int uniCharCodepoint = Utils::UTF8To32(&text[n], seqLen);
			if (seqLen == (unsigned char)-1)
				break; // malformated UTF8; what to do, what to do .. 

			n += seqLen;

			const sFontChar* character = GetChar(uniCharCodepoint);
			tw += character->advance_x;
		}
	}
	
	textWidth = (int)(tw * m_fFontScale + 0.5f);
	textHeight = (int)(m_maxHeight * m_fFontScale + 0.5f);
}

int CFontHybrid::GetKerning( const sFontChar* prevChar, const sFontChar* currChar ) const
{
	// should do this check on the outside, this function must be FAST
	//if(!m_bHasCustomKerning )
	//	return IFont::GetKerning( prevChar, currChar );

	FT_Vector delta;
	FT_Get_Kerning( m_face, prevChar->glyphIdx, currChar->glyphIdx, FT_KERNING_DEFAULT, &delta );

	return static_cast< int >( delta.x >> 6 );
}

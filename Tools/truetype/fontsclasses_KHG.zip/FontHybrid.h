#pragma once

#include "FontBase.h"
#include <unordered_map>

typedef struct FT_FaceRec_*    FT_Face;
typedef struct FT_LibraryRec_* FT_Library;

class CFontHybrid : public IFont
{
public:
	CFontHybrid();
	virtual ~CFontHybrid();
	virtual const sFontChar*	GetChar(const unsigned int key) override;
	virtual bool				Load() override;
	virtual void				GetFontMetrics(const char* text, int textLen, int kerning, int& textWidth, int& textHeight) override;
	virtual int					GetKerning(const sFontChar* prevChar, const sFontChar* currChar) const override;
	virtual bool				GetHasKerning() const override { return m_bHasCustomKerning; }

public:
	int							GetCharHeight() const { return m_actualCharHeight; }
	void						SetWantedCharHeight( int newCharHeight ) { m_wantedCharHeight = newCharHeight; } // use this before actual font creation

	void						SetPaddingLeft( int newPadding ) { m_paddingLeft = newPadding; } // use this before actual font creation
	void						SetPaddingRight( int newPadding ) { m_paddingRight = newPadding; } // use this before actual font creation
	void						SetPaddingTop( int newPadding ) { m_paddingTop = newPadding; } // use this before actual font creation
	void						SetPaddingBottom( int newPadding ) { m_paddingBottom = newPadding; } // use this before actual font creation

	void						GrowTexture();

	bool						InitTrueTypeFont( FT_Library library, FT_Face  );

	bool						LoadBitmapFont();
	bool						SaveBitmapFont( const char* pSavePath );

private:
	sFontChar*					AddChar( const unsigned int key );

private:
	std::unordered_map<unsigned int, sFontChar> m_charMap;

	// free type stuff
	FT_Library				m_library;
	FT_Face					m_face;

	int						m_textureWidth; // 2048 default
	int						m_textureHeight; // based on char height; power of 2

	int						m_addChar_xPos;
	int						m_addChar_yPos;

	int						m_wantedCharHeight;
	int						m_actualCharHeight;

	int						m_maxAboveBaseline_y; // pixels above font baseline; positive value
	int						m_minBelowBaseline_y; // pixels below font baseline; negative value

	int						m_paddingLeft; // default 2
	int						m_paddingRight;

	int						m_paddingTop; // default 2
	int						m_paddingBottom;

	bool					m_bHasCustomKerning;
};

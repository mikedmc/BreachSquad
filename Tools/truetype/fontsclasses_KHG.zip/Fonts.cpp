#include "Fonts.h"
#include "Kernel/FileManager.h"
#include "Kernel/Log.h"
#include "Kernel/Utils.h"
#include "Kernel/OS.h"
#include "tinyxml2/tinyxml2.h"
#include "FontBitmap.h"
#include "FontHybrid.h"

#include "ft2build.h"
#include FT_FREETYPE_H
#include FT_GLYPH_H

// CFontManager
//
CFontManager* CFontManager::mInstance = NULL;

void CFontManager::CreateInstance()
{
	ASSERT(!mInstance);
	if( !mInstance )
		mInstance = new CFontManager();
}

CFontManager* CFontManager::Instance()
{
	return mInstance;
}

void CFontManager::ReleaseInstance()
{
	SAFE_DELETE(mInstance);
}

sFreeTypeFontWrapper::~sFreeTypeFontWrapper()
{
	if (m_fontFace)
		FT_Done_Face(m_fontFace);
	SAFE_DELETE_ARRAY(m_pszFontName);
	SAFE_DELETE_ARRAY(m_pFileMem);
}

CFontManager::CFontManager()
{
	const unsigned int t1 = OS_GetTimeMsec();

	m_freeTypeLibrary = NULL;
	FT_Error error = FT_Init_FreeType(&m_freeTypeLibrary);
	if (error != 0)
		g_pLog->Write("[Error] CFontHybrid::LoadTrueTypeFont() Could not init FreeType font library! \n");

	// load all fonts from the /data/fonts/ folder, including mods and all folders added to the filesystem
	List<FileManager::sFilePath> files;
	g_fileManager->GetFolderContents("data/fonts", ".xml", files);
	for (int i = 0; i < files.Size(); ++i)
	{
		MergeFontsFile(files[i].path);
	}

	// init them
	for( int i(0); i < m_lFonts.Size(); ++i )
	{
		IFont* pFontEntry = m_lFonts[ i ];

		if (pFontEntry->m_eFontType == EFontType_Hybrid)
		{
			CFontHybrid* hybridFont = (CFontHybrid*)pFontEntry;

			// init FreeType library and font face			
			sFreeTypeFontWrapper* pFontFace = InitFreeTypeFontFace( pFontEntry->m_sFontFile.GetString() );
			hybridFont->InitTrueTypeFont( m_freeTypeLibrary, pFontFace->m_fontFace );
		}

		pFontEntry->Load();
	}

	const unsigned int t2 = OS_GetTimeMsec();
	LOG("Initializing fonts finished: %u msec\n", t2 - t1);
}

CFontManager::~CFontManager()
{
	for (int i(0); i < m_lFonts.Size(); ++i)
	{
		SAFE_DELETE(m_lFonts[i]);
	}
	m_lFonts.Free();

	for (int i(0); i < m_freeTypeFontFaces.Size(); ++i)
	{
		SAFE_DELETE(m_freeTypeFontFaces[i]);
	}
	m_freeTypeFontFaces.Free();

	if (m_freeTypeLibrary)
	{
		FT_Done_FreeType(m_freeTypeLibrary);
		m_freeTypeLibrary = NULL;
	}
}

sFreeTypeFontWrapper* CFontManager::InitFreeTypeFontFace( const char* szFilePath )
{
	for( int i(0); i < m_freeTypeFontFaces.Size(); ++i )
	{
		if( strncmp( m_freeTypeFontFaces[ i ]->m_pszFontName, szFilePath, Utils::strlen(  szFilePath ) )  == 0 )
			return m_freeTypeFontFaces[ i ];
	}

	sFreeTypeFontWrapper* newSmartPtrContainer = new sFreeTypeFontWrapper();

	// look for this font file in the mods
	char fileName[ MAX_PATH_STD ];
	bool isZip;
	g_fileManager->GetModdedFilePath(szFilePath, fileName, &isZip);

	newSmartPtrContainer->m_pszFontName = Utils::strdup( szFilePath );	

	g_pLog->Write("Loading %s%s\n", fileName, isZip ? " - zipped" : "");

	FT_Error error = 0;

	if (isZip)
	{
		unsigned int fileDataLen = 0;
		newSmartPtrContainer->m_pFileMem = g_fileManager->FileLoadBinary(fileName, &fileDataLen);
		error = FT_New_Memory_Face(m_freeTypeLibrary, newSmartPtrContainer->m_pFileMem, fileDataLen, 0, &newSmartPtrContainer->m_fontFace);
	}
	else
	{
		error = FT_New_Face(m_freeTypeLibrary, fileName, 0, &newSmartPtrContainer->m_fontFace);
	}

	if( error != 0 )
	{
		g_pLog->Write( "[Error] CFontManager::InitFreeTypeFontFace() Could not create font face from file '%s'! \n", fileName );
		
		SAFE_DELETE( newSmartPtrContainer );
		return NULL;
	}

	m_freeTypeFontFaces.Add( newSmartPtrContainer );
	return newSmartPtrContainer;
}

bool CFontManager::MergeFontsFile( const char* pszFontsFile )
{
	tinyxml2::XMLDocument doc;
	bool bLoaded = g_fileManager->LoadXML( pszFontsFile, doc );
	if (!bLoaded)
		return false;

	const tinyxml2::XMLElement* pRoot = doc.FirstChildElement( "Fonts" );
	ASSERT(pRoot);
	if (!pRoot)
	{
		// not really a fonts library, don't load. This happens because we parse the entire data/fonts folder for any libraries
		return false;
	}

	// count entries
	int numFonts = 0;
	for( const tinyxml2::XMLElement* pFont = pRoot->FirstChildElement(); pFont; pFont = pFont->NextSiblingElement() )
		++numFonts;

	// load fonts
	m_lFonts.Reserve( m_lFonts.Size() + numFonts );

	for( const tinyxml2::XMLElement* pFont = pRoot->FirstChildElement( "Font" ); pFont; pFont = pFont->NextSiblingElement( "Font" ) )
	{
		const char* pszXMLFontName = pFont->Attribute("name");
		const char* pszXMLFontType = pFont->Attribute("type");
		const char* pszXMLFontFile = pFont->Attribute("file");
		const int iXMLFontSize = pFont->IntAttribute("size", 0);

		// see if it's unique
		for (int i = 0; i < m_lFonts.Size(); ++i)
		{
			if (Utils::strcmp(m_lFonts[i]->m_sFontName.GetString(), pszXMLFontName) != 0)
				continue;

			LOG("[Warning] overwriting font %s\n", pszXMLFontName);
			delete m_lFonts[i];
			m_lFonts.Remove(i--);
		}

		IFont* font = NULL;

		if (Utils::strcmp(pszXMLFontType, "hybrid") == 0)
		{
			CFontHybrid* hybridFont = new CFontHybrid();
			font = hybridFont;

			const char* pszXMLFontCharHeight = pFont->Attribute( "forceCharHeight" ); // for hybrid fonts only
			const char* pszXMLFontPaddingLeft = pFont->Attribute( "paddingLeft" ); // for hybrid fonts only
			const char* pszXMLFontPaddingRight = pFont->Attribute( "paddingRight" ); // for hybrid fonts only
			const char* pszXMLFontPaddingTop = pFont->Attribute( "paddingTop" ); // for hybrid fonts only
			const char* pszXMLFontPaddingBottom = pFont->Attribute( "paddingBottom" ); // for hybrid fonts only

			if( pszXMLFontCharHeight )
				hybridFont->SetWantedCharHeight( atoi( pszXMLFontCharHeight ) );

			if( pszXMLFontPaddingLeft )
				hybridFont->SetPaddingLeft( atoi( pszXMLFontPaddingLeft ) );

			if( pszXMLFontPaddingRight )
				hybridFont->SetPaddingRight( atoi( pszXMLFontPaddingRight ) );

			if( pszXMLFontPaddingTop )
				hybridFont->SetPaddingTop( atoi( pszXMLFontPaddingTop ) );

			if( pszXMLFontPaddingBottom )
				hybridFont->SetPaddingBottom( atoi( pszXMLFontPaddingBottom ) );
		}
		else
		if (Utils::strcmp(pszXMLFontType, "bitmap") == 0)
		{
			font = new CFontBitmap();
		}

		if (!font)
		{
			DEBUG_BREAK();
			continue;
		}

		// store stuff
		m_lFonts.Add(font);
		font->m_sFontName.CreateHash( pszXMLFontName, true );
		font->m_sFontFile.CreateHash( pszXMLFontFile, true );
		font->m_iFontSize = iXMLFontSize;
	}

	return true;
}

IFont* CFontManager::GetFont( const char* szFontName ) const
{
	HashedString sFontName = HashedString::GetHash(szFontName);
	for (int i(0); i < m_lFonts.Size(); ++i)
	{
		if (m_lFonts[i]->m_sFontName == sFontName)
			return m_lFonts[i];
	}
	LOG_ERROR("[Error] cannot find font '%s'\n", szFontName);
	return m_lFonts[0];
}

IFont* CFontManager::GetFont( const HashedString& sFontName ) const
{
	for( int i(0); i < m_lFonts.Size(); ++i )
	{
		if( m_lFonts[ i ]->m_sFontName == sFontName )
			return m_lFonts[ i ];
	}
	LOG_ERROR("[Error] cannot find font '%s'\n", sFontName.GetString());
	return m_lFonts[ 0 ]; // fallback so we don't crash
}

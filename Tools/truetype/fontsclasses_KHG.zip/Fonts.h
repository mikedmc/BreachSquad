#pragma once

#include "Kernel/CommonDefs.h"
#include "Kernel/List.h"
#include "FontBase.h"

typedef struct FT_LibraryRec_* FT_Library;
typedef struct FT_FaceRec_*    FT_Face;

struct sFreeTypeFontWrapper
{
		sFreeTypeFontWrapper()
		{
			m_pFileMem = NULL;
			m_pszFontName = NULL;
		}
		~sFreeTypeFontWrapper();

		char*			m_pszFontName;
		unsigned char*	m_pFileMem; // only valid when loading the font from a zip file
		FT_Face			m_fontFace;
};

class CFontManager
{
	private:
										CFontManager();
										~CFontManager();
		static CFontManager*			mInstance;	// singleton instance

	public:
		static void						CreateInstance();
		static CFontManager*			Instance();
		static void						ReleaseInstance();

		IFont*							GetFont(const char* szFontName) const;
		IFont*							GetFont(const HashedString& sFontName) const;
		const List<IFont*>&				GetFonts() const { return m_lFonts; }

	private:
		bool							MergeFontsFile(const char* pszFontsFile);
		sFreeTypeFontWrapper*			InitFreeTypeFontFace(const char* szFilePath);

	public:
		List<IFont*>					m_lFonts;

	protected:
		FT_Library						m_freeTypeLibrary;
		List<sFreeTypeFontWrapper*>		m_freeTypeFontFaces;
};
